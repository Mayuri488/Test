package com.yash.controller;

import org.springframework.web.bind.annotation.RestController;

/**
 * Created by mayuri.patil on 19-09-2017.
 */
@RestController
public class ClientController {


}
