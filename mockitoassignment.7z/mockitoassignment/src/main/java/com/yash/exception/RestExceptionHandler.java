package com.yash.exception;

import org.springframework.web.bind.annotation.ControllerAdvice;

/**
 * Created by mayuri.patil on 19-09-2017.
 */
@ControllerAdvice
public class RestExceptionHandler {


}
