package com.yash.dao;

import com.yash.model.Client;

/**
 * Created by mayuri.patil on 20-09-2017.
 */
public interface ClientDao {
    public Client getClientById(Integer id);
}
