package com.yash.service;

import com.yash.model.Client;

/**
 * Created by mayuri.patil on 19-09-2017.
 */
public interface ClientService {
    public Client getClientById(Integer id);
}
